package javacollecteur;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * Classe dÃ©rivÃ©e de gestion de la couche persistance base de donnÃ©es Oracle
 * @author Fabien RETIF
 * @version 1.0
 */
public class BD
{

    private String connexionString = "";
    private Connection laConnexion = null;

    public BD()
    {
        connexionString = "jdbc:oracle:thin:@v240.ig.polytech.univ-montp2.fr:1521:ORA10";
    }

    /**
      * @fn openDataAccess () throws Exception
      * @brief ProcÃ©dure d'ouverture du conteneur
     *  @throws Exception en cas d'erreur
    */
    public synchronized  void openDataAccess () throws Exception
    {
        Class cDriverOracle=Class.forName("oracle.jdbc.driver.OracleDriver");
        Driver dDriverOracle=(java.sql.Driver)cDriverOracle.newInstance();
        DriverManager.registerDriver(dDriverOracle);
        laConnexion=DriverManager.getConnection("jdbc:oracle:thin:@v240.ig.polytech.univ-montp2.fr:1521:ORA10","damien.vacher","oracle");
    }

    /**
      * @fn clisenDataAccess () throws Exception
      * @brief ProcÃ©dure de fermeture du conteneur
     * @throws Exception en cas d'erreur
    */
    public synchronized void closeDataAccess() throws Exception
    {
        laConnexion.close();
    }
   
    public synchronized List<Map> getLesSociete()  throws Exception
    {
       List<Map> lesResultats = new ArrayList<Map>();
       Map<String,String> uneLigne = null;
       Statement laRequete = null;

       openDataAccess();
       laRequete = laConnexion.createStatement();
       ResultSet rs= laRequete.executeQuery("Select ISIN, Adresse_site from Entreprise_E");

       while(rs.next())
       {
           uneLigne = new HashMap<String,String>();
           //On ajoute couple nomAttribut/Valeur
           uneLigne.put("idEuroNext", rs.getObject(1).toString());
           uneLigne.put("url", rs.getObject(2).toString());
         
           //On ajoute la ligne dans les rÃ©sultats
           lesResultats.add(uneLigne);
       }

       laRequete.close();
       closeDataAccess();
       return lesResultats;

    }

     public synchronized List<Map> getLesMotsCles()  throws Exception
    {
       List<Map> lesResultats = new ArrayList<Map>();
       Map<String,String> uneLigne = null;
       Statement laRequete = null;

       openDataAccess();
       laRequete = laConnexion.createStatement();
       ResultSet rs= laRequete.executeQuery("Select Mot, Type_Mot from Mots_Cles");

       while(rs.next())
       {
           uneLigne = new HashMap<String,String>();

           //On ajoute couple nomAttribut/Valeur
           uneLigne.put("idMotCle", rs.getObject(1).toString());
           uneLigne.put("libelleMotCle", rs.getObject(2).toString());

           //On ajoute la ligne dans les rÃ©sultats
           lesResultats.add(uneLigne);
       }

       laRequete.close();
       closeDataAccess();

       return lesResultats;
    }
  
    public synchronized String estDejaVu(String url,String page)  throws Exception
    {      
       String res = "0";
       Statement laRequete = null;

        if(page.isEmpty())
           page = "/";
      
       openDataAccess();
       laRequete = laConnexion.createStatement();
       ResultSet rs= laRequete.executeQuery("select count(*) from Site_Web where Adresse_Site='"+url+"' and Est_accede_Par = '"+page+"'");

       if(rs.next())
       {
          res = rs.getObject(1).toString();
       }

       laRequete.close();
       closeDataAccess();

       return res;

       
    }
   
    public synchronized void insert(String url,String page,String idMotCle,String pos)  throws Exception
    {       
       Statement laRequete = null;
       openDataAccess();      

       if(page.isEmpty())
           page = "/";       
    
       laRequete = laConnexion.createStatement();
       if(estDejaTrouve(url, page, idMotCle, pos).equalsIgnoreCase("0"))
       {
    	   System.out.println("J'ins�re un nouveau mot");
    	   System.out.println(idMotCle);
              laRequete.execute("Insert into est_present values('"+url+"','"+idMotCle+"',1)");
       }
      else
       {
    	  System.out.println("J'update une page pour laquelle j'ai dŽjˆ trouvŽ un mot");
               laRequete.execute("update est_present set nombre_occurences = nombre_occurences+1 where adresse_page='"+url+"' and Mot='"+idMotCle+"'");
       }
     
      laRequete.close();
      
       closeDataAccess();
       
    }

     public synchronized String estDejaTrouve(String url,String page,String idMotCle,String pos)  throws Exception
    {
       String res = "0";
       Statement laRequete = null;

        if(page.isEmpty())
           page = "/";

       openDataAccess();
       laRequete = laConnexion.createStatement();
       ResultSet rs= laRequete.executeQuery("select count(*) from est_present where adresse_page='"+url+"' and Mot='"+idMotCle+"'");

       if(rs.next())
       {
          res = rs.getObject(1).toString();
       }

       laRequete.close();
       closeDataAccess();

       return res;


    }    
/*
     public synchronized void insertPage(String url,String page)  throws Exception
    {
       Statement laRequete = null;
       openDataAccess();  

       if(page.isEmpty())
           page = "/";

       laRequete = laConnexion.createStatement();
       laRequete.execute("Insert into page values('"+url+"','"+page+"')");
       laRequete.close();


       closeDataAccess();

    }
   */
}
